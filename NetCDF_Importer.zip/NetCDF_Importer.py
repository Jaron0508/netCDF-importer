bl_info = {
    "name": "NetCDF Importer",
    "author": "Jaron Theurer",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > N",
    "description": "Visualize ENVI-met netCDF files",
    "warning": "",
    "doc_url": "",
    "category": "",
}

# Basic modules:
import bpy
import bpy_extras
import netCDF4
import numpy as np
import bmesh

# User interface modules:
from bpy_extras.io_utils import ImportHelper

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       PointerProperty)

from bpy.types import (Panel,
                       Operator,
                       PropertyGroup)


# ------------------------------------------------------------------------
#    Object Mesh
# ------------------------------------------------------------------------

def createObjectMesh(mesh_name, coords_list, objects_id):
    """Creates a mesh from object coordinates"""

    # Define six faces for every cube
    # Every tuple describes one face connected by four vertices
    faces = [(0, 1, 2, 3),
             (4, 7, 6, 5),
             (0, 4, 5, 1),
             (1, 5, 6, 2),
             (2, 6, 7, 3),
             (4, 0, 3, 7)]

    # Create a new mesh and bmesh
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()

    # Loop over coordinates list to get vertices locations for objects
    for t in coords_list:
        if t[3] == objects_id:
            # Every tuple in verts_loc describes the location of one vertex (x, y, z)
            # The location of every vertex is calculated from grid location and grid size
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),  
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),   
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),   
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),   
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]

            # Write location of vertices to bmesh
            for v_co in verts_loc:
                bm.verts.new(v_co)

    # This has to be called before writing new faces to bmesh
    bm.verts.ensure_lookup_table()

    # For every set of vertices (for every created cube)
    for i in range(0, int(len(bm.verts)/8)):
        # For every face of the cube (for all six faces)
        for f_idx in faces:
            # Create a new face between four vertices from bm.verts coordinates
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    # Write bmesh data to blender mesh and update it
    bm.to_mesh(mesh)
    mesh.update()

    # Convert mesh to object
    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Soil Mesh
# ------------------------------------------------------------------------

def createSoilMesh(mesh_name, coords_list, soil_id):
    """Creates a mesh from soil coordinates"""

    faces = [(0, 1, 2, 3),
             (4, 7, 6, 5),
             (0, 4, 5, 1),
             (1, 5, 6, 2),
             (2, 6, 7, 3),
             (4, 0, 3, 7)]

    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()

    for t in coords_list:
        if t[2] == soil_id: 
            # The added_height list contains summed up height values for cubes calculated from their z-size
            # The values of DEMOffset are used as an index for that list to get terrain heights
            verts_loc = [(t[0]+t[3]/2, t[1]+t[4]/2, 0),
                         (t[0]+t[3]/2, t[1]-t[4]/2, 0),
                         (t[0]-t[3]/2, t[1]-t[4]/2, 0),
                         (t[0]-t[3]/2, t[1]+t[4]/2, 0),
                         (t[0]+t[3]/2, t[1]+t[4]/2, 0.05+added_height[t[5]]),
                         (t[0]+t[3]/2, t[1]-t[4]/2, 0.05+added_height[t[5]]),
                         (t[0]-t[3]/2, t[1]-t[4]/2, 0.05+added_height[t[5]]),
                         (t[0]-t[3]/2, t[1]+t[4]/2, 0.05+added_height[t[5]])]
                         # Add 5 cm to all vertices above cell midpoint to reduce clipping in viewport

            for v_co in verts_loc:
                bm.verts.new(v_co)

    bm.verts.ensure_lookup_table()

    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    bm.to_mesh(mesh)
    mesh.update()

    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Air Temperature Mesh
# ------------------------------------------------------------------------

def createAirTempMesh(mesh_name, coords_list, color_value):
    """Creates a mesh from temperature coordinates"""
    
    faces = [(0, 1, 2, 3),
             (4, 7, 6, 5),
             (0, 4, 5, 1),
             (1, 5, 6, 2),
             (2, 6, 7, 3),
             (4, 0, 3, 7)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()
    
    for t in coords_list:
        if t[7] == color_value:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),  
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),   
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),   
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),   
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]
            
            for v_co in verts_loc:
                bm.verts.new(v_co)
            
    bm.verts.ensure_lookup_table()
    
    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])
        
    bm.to_mesh(mesh)
    mesh.update()

    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Biomet Mesh
# ------------------------------------------------------------------------

def createBiometMesh(mesh_name, coords_list, color_value):
    """Creates a mesh from biomet coordinates"""

    faces = [(0, 1, 2, 3),
             (4, 7, 6, 5),
             (0, 4, 5, 1),
             (1, 5, 6, 2),
             (2, 6, 7, 3),
             (4, 0, 3, 7)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()

    for t in coords_list:
        if t[6] == color_value:
            verts_loc = [(t[0]+t[3]/2, t[1]+t[4]/2, 0+added_height[t[5]]),
                         (t[0]+t[3]/2, t[1]-t[4]/2, 0+added_height[t[5]]),   
                         (t[0]-t[3]/2, t[1]-t[4]/2, 0+added_height[t[5]]),   
                         (t[0]-t[3]/2, t[1]+t[4]/2, 0+added_height[t[5]]),   
                         (t[0]+t[3]/2, t[1]+t[4]/2, 0.10+added_height[t[5]]),
                         (t[0]+t[3]/2, t[1]-t[4]/2, 0.10+added_height[t[5]]),
                         (t[0]-t[3]/2, t[1]-t[4]/2, 0.10+added_height[t[5]]),
                         (t[0]-t[3]/2, t[1]+t[4]/2, 0.10+added_height[t[5]])]
                         # Add 10 cm to all vertices above cell midpoint to reduce clipping with soil
                         # Since biomet variables are only 3-dimensional (time,y,x), shift all vertices along the z-axis

            for v_co in verts_loc:
                bm.verts.new(v_co)

    bm.verts.ensure_lookup_table()

    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    bm.to_mesh(mesh)
    mesh.update()
    
    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Walls X Mesh
# ------------------------------------------------------------------------

def createSingleWallX(mesh_name, coords_list, walls_id):
    """Creates a mesh for every x-wall without greening"""
    
    # Define a face that points in the x-direction
    faces = [(2, 6, 7, 3)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()
    
    for t in coords_list:
        # If walls_id exists and greening does not exist
        if t[3] == walls_id and t[7] == -999:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]
            
            for v_co in verts_loc:
                bm.verts.new(v_co)
                
    bm.verts.ensure_lookup_table()
    
    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    bm.to_mesh(mesh)
    mesh.update()
    
    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Walls Y Mesh
# ------------------------------------------------------------------------

def createSingleWallY(mesh_name, coords_list, walls_id):
    """Creates a mesh for every y-wall without greening"""
        
    faces = [(1, 5, 6, 2)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()
   
    for t in coords_list:
        if t[3] == walls_id and t[7] == -999:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]
            
            for v_co in verts_loc:
                bm.verts.new(v_co)
                
    bm.verts.ensure_lookup_table()
    
    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])
      
    bm.to_mesh(mesh)
    mesh.update()
    
    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Walls Z Mesh
# ------------------------------------------------------------------------

def createSingleWallZ(mesh_name, coords_list, walls_id):
    """Creates a mesh for every z-wall without greening"""
   
    faces = [(0, 1, 2, 3)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()
   
    for t in coords_list:
        if t[3] == walls_id and t[7] == -999:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]
            
            for v_co in verts_loc:
                bm.verts.new(v_co)
                
    bm.verts.ensure_lookup_table()
    
    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    bm.to_mesh(mesh)
    mesh.update()
    
    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Greening X Mesh
# ------------------------------------------------------------------------

def createGreeningX(mesh_name, coords_list):
    """Creates a mesh for every x-greening"""

    faces = [(2, 6, 7, 3)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()
   
    for t in coords_list:
        # If greening (leaf temperature) exists
        if t[7] != -999:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]
            
            for v_co in verts_loc:
                bm.verts.new(v_co)

    bm.verts.ensure_lookup_table()

    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])
 
    bm.to_mesh(mesh)
    mesh.update()

    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Greening Y Mesh
# ------------------------------------------------------------------------

def createGreeningY(mesh_name, coords_list):
    """Creates a mesh for every y-greening"""
    
    faces = [(1, 5, 6, 2)]

    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()

    for t in coords_list:
        if t[7] != -999:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]

            for v_co in verts_loc:
                bm.verts.new(v_co)

    bm.verts.ensure_lookup_table()
    
    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    bm.to_mesh(mesh)
    mesh.update()

    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Greening Z Mesh
# ------------------------------------------------------------------------

def createGreeningZ(mesh_name, coords_list):
    """Creates a mesh for every z-greening"""
 
    faces = [(0, 1, 2, 3)]
    
    mesh = bpy.data.meshes.new(mesh_name)
    bm = bmesh.new()
   
    for t in coords_list:
        if t[7] != -999:
            verts_loc = [(t[0]+t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]-t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]-t[6]/2),
                         (t[0]+t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2),
                         (t[0]+t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]-t[5]/2, t[2]+t[6]/2),
                         (t[0]-t[4]/2, t[1]+t[5]/2, t[2]+t[6]/2)]
            
            for v_co in verts_loc:
                bm.verts.new(v_co)
                
    bm.verts.ensure_lookup_table()
    
    for i in range(0, int(len(bm.verts)/8)):
        for f_idx in faces:
            bm.faces.new([bm.verts[f_idx[0]+i*8],
                          bm.verts[f_idx[1]+i*8], 
                          bm.verts[f_idx[2]+i*8],
                          bm.verts[f_idx[3]+i*8]])

    bm.to_mesh(mesh)
    mesh.update()
    
    bpy_extras.object_utils.object_data_add(bpy.context, mesh)


# ------------------------------------------------------------------------
#    Material
# ------------------------------------------------------------------------

# Create new material:
def newMaterial(id):

    # Check if material already exists
    mat = bpy.data.materials.get(id)

    # Create a new material if material does not exist
    if mat is None:
        mat = bpy.data.materials.new(name=id)

    # Use node tree
    mat.use_nodes = True

    # Remove existing nodes and links
    if mat.node_tree:
        mat.node_tree.links.clear()
        mat.node_tree.nodes.clear()

    return mat


# Add shader to material:
def newShader(id, r, g, b, a=1):

    mat = newMaterial(id)

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    
    # Define "Principled BSDF" and "Output Material" node 
    output = nodes.new(type='ShaderNodeOutputMaterial')
    shader = nodes.new(type='ShaderNodeBsdfPrincipled')
    
    # Create a new "Principled BSDF" node and set r, g, b values
    nodes["Principled BSDF"].inputs[0].default_value = (r, g, b, 1)
    # Set alpha value (used for glass material)
    nodes["Principled BSDF"].inputs[21].default_value = a
    
    # Link "Principled BSDF" node to "Output Material" node
    links.new(shader.outputs[0], output.inputs[0])

    return mat


# Apply material to active object:
def applyMaterial(id, r, g, b, a=1):

    mat = newShader(id, r, g, b, a)
    bpy.context.active_object.data.materials.append(mat)


# Clean up mesh:
def cleanUp():
    
    # Set object origin to center of geometry
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')

    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')


# ------------------------------------------------------------------------
#    Collections
# ------------------------------------------------------------------------

# Move cubes to collection:
def moveToCollection(collection_name):
    
    c = bpy.context
    objs = c.selected_objects
    
    # Set target collection to a known collection
    coll_target = c.scene.collection.children.get(collection_name)

    # If collection exists and objects are selected
    if coll_target and objs:
        # Loop through all selected objects
        for ob in objs:
            # Loop through all collections and unlink selected object
            for coll in ob.users_collection:
                coll.objects.unlink(ob)

            # link objects to target collection
            coll_target.objects.link(ob)


# Move air temperature cubes to collection:
def moveAirTempToCollection(sim_time, height):
    
    c = bpy.context
    objs = c.selected_objects
    coll_target = c.scene.collection.children.get("Temperature, height: " + str(height) + ", time: " + str(sim_time))

    if coll_target and objs:
        for ob in objs:
            for coll in ob.users_collection:
                coll.objects.unlink(ob)

            coll_target.objects.link(ob)


# ------------------------------------------------------------------------
#    Other
# ------------------------------------------------------------------------

def isOutsideCube(z,y,x):
    """Returns true if cube is visible form the outside"""
    
    try:
        if objects[0,z,y,x-1] == 0:
            return True
        elif objects[0,z,y-1,x] == 0:
            return True
        elif objects[0,z-1,y,x] == 0:
            return True
        elif objects[0,z,y,x+1] == 0:
            return True
        elif objects[0,z,y+1,x] == 0:
            return True
        elif objects[0,z+1,y,x] == 0:
            return True
    # Include IndexError for cubes at the edge of simulation area 
    except IndexError:
        return True


# ------------------------------------------------------------------------
#    Buildings
# ------------------------------------------------------------------------

def getBuildings():
    """Creates a list of coordinates for buildings and calls mesh functions"""

    # Define filepath
    f = netCDF4.Dataset(selected_file)

    # Get objects id from variables
    # Make objects a global variable for isOutsideCube function
    global objects
    objects = np.array(f.variables["Objects"])

    # Get location of cubes from variables
    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    # Get size of cubes from global attributes
    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")


    # Create list of coordinates for buildings
    coords_objects = []
    for z in range(0,len(loc_z)):
        for y in range(0,len(loc_y)):
            for x in range(0,len(loc_x)):
                if isOutsideCube(z,y,x) == True:
                    coords_objects.append((loc_x[x], loc_y[y], loc_z[z], int(objects[0,z,y,x]), size_x[x], size_y[y], size_z[z]))


    # Create new collection for objects
    collection = bpy.data.collections.new("Buildings")
    bpy.context.scene.collection.children.link(collection)

    # Convert list of coordinates to numpy array
    coords_objects_array = np.array(coords_objects)


    # Create buildings mesh
    if 1 in coords_objects_array[:,3]:
        # Buildings
        createObjectMesh("Buildings", coords_objects, 1)
        applyMaterial("Buildings", 0.28, 0.28, 0.28)
        moveToCollection("Buildings")
        cleanUp()


# ------------------------------------------------------------------------
#    Vegetation
# ------------------------------------------------------------------------

def getVegetation():
    """Creates a list of coordinates for vegetation and calls mesh functions"""

    f = netCDF4.Dataset(selected_file)

    global objects
    objects = np.array(f.variables["Objects"])

    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")


    # Create list of coordinates for vegetation
    coords_objects = []
    for z in range(0,len(loc_z)):
        for y in range(0,len(loc_y)):
            for x in range(0,len(loc_x)):
                if isOutsideCube(z,y,x) == True:
                    coords_objects.append((loc_x[x], loc_y[y], loc_z[z], int(objects[0,z,y,x]), size_x[x], size_y[y], size_z[z]))


    # Create new collection for vegetation
    collection = bpy.data.collections.new("Vegetation")
    bpy.context.scene.collection.children.link(collection)

    # Convert coordinates list to numpy array
    coords_objects_array = np.array(coords_objects)


    # Create vegetation mesh
    if 11 in coords_objects_array[:,3]:
        # Vegetation LAD lower 0.5
        createObjectMesh("Vegetation (LAD lower 0.5)", coords_objects, 11)
        applyMaterial("Vegetation LAD lower 0.5", 0.084, 0.342, 0.028)
        moveToCollection("Vegetation")
        cleanUp()

    if 12 in coords_objects_array[:,3]:
        # Vegetation LAD 0.5 - 1.0
        createObjectMesh("Vegetation (LAD 0.5 - 1.0)", coords_objects, 12)
        applyMaterial("Vegetation LAD 0.5 - 1.0", 0.013, 0.319, 0.012)
        moveToCollection("Vegetation")
        cleanUp()

    if 13 in coords_objects_array[:,3]:
        # Vegetation LAD 1.0 - 1.5
        createObjectMesh("Vegetation (LAD 1.0 - 1.5)", coords_objects, 13)
        applyMaterial("Vegetation LAD 1.0 - 1.5", 0.004, 0.214, 0)
        moveToCollection("Vegetation")
        cleanUp()
    
    if 14 in coords_objects_array[:,3]:
        # Vegetation LAD 1.5 - 2.0
        createObjectMesh("Vegetation (LAD 1.5 - 2.0)", coords_objects, 14)
        applyMaterial("Vegetation LAD 1.5 - 2.0", 0.01, 0.15, 0)
        moveToCollection("Vegetation")
        cleanUp()

    if 15 in coords_objects_array[:,3]:
        # Vegetation LAD above 2.0
        createObjectMesh("Vegetation (LAD above 2.0)", coords_objects, 15)
        applyMaterial("Vegetation LAD above 2.0", 0, 0.1, 0)
        moveToCollection("Vegetation")
        cleanUp()


# ------------------------------------------------------------------------
#    Soil
# ------------------------------------------------------------------------

def getSoil():
    """Creates a list of coordinates for soil and calls mesh functions"""

    f = netCDF4.Dataset(selected_file)
    
    soilprofiletype = np.array(f.variables["SoilProfileType"])
    dem_offset = np.array(f.variables["DEMOffset"])

    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")

    # List of added heights for terrain height
    global added_height
    added_height = [0, size_z[0]]
    for i in range(1,len(size_z)):
        h = size_z[i] + added_height[-1]
        added_height.append(h)


    # Create list of coordinates for soil
    coords_soil = []
    for y in range(0,len(loc_y)):
        for x in range(0,len(loc_x)):
            coords_soil.append((loc_x[x], loc_y[y], int(soilprofiletype[0,y,x]), size_x[x], size_y[y], int(dem_offset[0,y,x])))


    # Create a new collection for soil
    collection = bpy.data.collections.new("Soil")
    bpy.context.scene.collection.children.link(collection)

    # Convert coordinates list to numpy array
    coords_soil_array = np.array(coords_soil)
  
  
    # Create soil mesh
    if 2000 in coords_soil_array[:,2]:
        # Default Unsealed Soil (Sandy Loam)
        createSoilMesh("Sandy Loam", coords_soil, 2000)
        applyMaterial("Sandy Loam", 0.413, 0.283, 0.178)
        moveToCollection("Soil")
        cleanUp()

    if 2001 in coords_soil_array[:,2]:
        # Default Unsealed Soil (Sandy Loam)
        createSoilMesh("Sandy Loam", coords_soil, 2001)
        applyMaterial("Sandy Loam", 0.413, 0.283, 0.178)
        moveToCollection("Soil")
        cleanUp()

    if 2002 in coords_soil_array[:,2]:
        # Unsealed Soil (Loamy Soil)
        createSoilMesh("Loamy Soil", coords_soil, 2002)
        applyMaterial("Loamy Soil", 0.09, 0.04, 0.02)
        moveToCollection("Soil")
        cleanUp()

    if 2003 in coords_soil_array[:,2]:
        # Asphalt Road
        createSoilMesh("Asphalt Road", coords_soil, 2003)
        applyMaterial("Asphalt Road", 0.006, 0.006, 0.006)
        moveToCollection("Soil")
        cleanUp()

    if 2004 in coords_soil_array[:,2]:
        # Asphalt Road
        createSoilMesh("Asphalt Road", coords_soil, 2004)
        applyMaterial("Asphalt Road", 0.006, 0.006, 0.006)
        moveToCollection("Soil")
        cleanUp()

    if 2005 in coords_soil_array[:,2]:
        # Pavement (Concrete), dirty
        createSoilMesh("Pavement (Concrete) dirty", coords_soil, 2005)
        applyMaterial("Pavement (Concrete) dirty", 0.107, 0.132, 0.157)
        moveToCollection("Soil")
        cleanUp()

    if 2006 in coords_soil_array[:,2]:
        # Pavement (Concrete), dirty
        createSoilMesh("Pavement (Concrete) dirty", coords_soil, 2006)
        applyMaterial("Pavement (Concrete) dirty", 0.107, 0.132, 0.157)
        moveToCollection("Soil")
        cleanUp()

    if 2007 in coords_soil_array[:,2]:
        # Loamy Soil
        createSoilMesh("Loamy Soil", coords_soil, 2007)
        applyMaterial("Loamy Soil", 0.09, 0.04, 0.02)
        moveToCollection("Soil")
        cleanUp()

    if 2008 in coords_soil_array[:,2]:
        # Loamy Soil
        createSoilMesh("Loamy Soil", coords_soil, 2008)
        applyMaterial("Loamy Soil", 0.09, 0.04, 0.02)
        moveToCollection("Soil")
        cleanUp()

    if 2009 in coords_soil_array[:,2]:
        # Loamy Soil
        createSoilMesh("Loamy Soil", coords_soil, 2009)
        applyMaterial("Loamy Soil", 0.09, 0.04, 0.02)
        moveToCollection("Soil")
        cleanUp()

    if 2010 in coords_soil_array[:,2]:
        # Sandy Soil
        createSoilMesh("Sandy Soil", coords_soil, 2010)
        applyMaterial("Sandy Soil", 0.27, 0.122, 0.028)
        moveToCollection("Soil")
        cleanUp()

    if 2011 in coords_soil_array[:,2]:
        # Sandy Soil
        createSoilMesh("Sandy Soil", coords_soil, 2011)
        applyMaterial("Sandy Soil", 0.27, 0.122, 0.028)
        moveToCollection("Soil")
        cleanUp()

    if 2012 in coords_soil_array[:,2]:
        # Deep Water
        createSoilMesh("Deep Water", coords_soil, 2012)
        applyMaterial("Deep Water", 0.01, 0.01, 1)
        moveToCollection("Soil")
        cleanUp()

    if 2013 in coords_soil_array[:,2]:
        # Deep Water
        createSoilMesh("Deep Water", coords_soil, 2013)
        applyMaterial("Deep Water", 0.01, 0.01, 1)
        moveToCollection("Soil")
        cleanUp()

    if 2014 in coords_soil_array[:,2]:
        # Brick Road (red stones)
        createSoilMesh("Brick Road (red stones)", coords_soil, 2014)
        applyMaterial("Brick Road (red stones)", 0.102, 0.004, 0.003)
        moveToCollection("Soil")
        cleanUp()

    if 2015 in coords_soil_array[:,2]:
        # Brick Road (red stones)
        createSoilMesh("Brick Road (red stones)", coords_soil, 2015)
        applyMaterial("Brick Road (red stones)", 0.102, 0.004, 0.003)
        moveToCollection("Soil")
        cleanUp()

    if 2016 in coords_soil_array[:,2]:
        # Brick Road (yellow stones)
        createSoilMesh("Brick Road (yellow stones)", coords_soil, 2016)
        applyMaterial("Brick Road (yellow stones)", 0.5, 0.28, 0.004)
        moveToCollection("Soil")
        cleanUp()

    if 2017 in coords_soil_array[:,2]:
        # Brick Road (yellow stones)
        createSoilMesh("Brick Road (yellow stones)", coords_soil, 2017)
        applyMaterial("Brick Road (yellow stones)", 0.5, 0.28, 0.004)
        moveToCollection("Soil")
        cleanUp()

    if 2018 in coords_soil_array[:,2]:
        # Dark Granit Pavement
        createSoilMesh("Dark Granit Pavement", coords_soil, 2018)
        applyMaterial("Dark Granit Pavement", 0.035, 0.027, 0.019)
        moveToCollection("Soil")
        cleanUp()

    if 2019 in coords_soil_array[:,2]:
        # Dark Granit Pavement
        createSoilMesh("Dark Granit Pavement", coords_soil, 2019)
        applyMaterial("Dark Granit Pavement", 0.035, 0.027, 0.019)
        moveToCollection("Soil")
        cleanUp()

    if 2020 in coords_soil_array[:,2]:
        # Granit Pavement (single stones)
        createSoilMesh("Granit Pavement (single stones)", coords_soil, 2020)
        applyMaterial("Granit Pavement (single stones)", 0.162, 0.162, 0.162)
        moveToCollection("Soil")
        cleanUp()

    if 2021 in coords_soil_array[:,2]:
        # Granit Pavement (single stones)
        createSoilMesh("Granit Pavement (single stones)", coords_soil, 2021)
        applyMaterial("Granit Pavement (single stones)", 0.162, 0.162, 0.162)
        moveToCollection("Soil")
        cleanUp()

    if 2022 in coords_soil_array[:,2]:
        # Granit shining
        createSoilMesh("Granit shining)", coords_soil, 2022)
        applyMaterial("Granit shining", 0.037, 0.022, 0.029)
        moveToCollection("Soil")
        cleanUp()

    if 2023 in coords_soil_array[:,2]:
        # Granit shining
        createSoilMesh("Granit shining)", coords_soil, 2023)
        applyMaterial("Granit shining", 0.037, 0.022, 0.029)
        moveToCollection("Soil")
        cleanUp()

        # Wet Concrete TEST (id = 2024)
        # Wet Concrete Test (id = 2025)
        # PhotocatTest (id = 2026)
        # PhotocatTest (id = 2027)

    if 2028 in coords_soil_array[:,2]:
        # Concrete Pavement Gray
        createSoilMesh("Concrete Pavement Gray", coords_soil, 2028)
        applyMaterial("Concrete Pavement Gray", 0.1, 0.1, 0.1)
        moveToCollection("Soil")
        cleanUp()

    if 2029 in coords_soil_array[:,2]:
        # Concrete Pavement Gray
        createSoilMesh("Concrete Pavement Gray", coords_soil, 2029)
        applyMaterial("Concrete Pavement Gray", 0.1, 0.1, 0.1)
        moveToCollection("Soil")
        cleanUp()

    if 2030 in coords_soil_array[:,2]:
        # Concrete Pavement Light
        createSoilMesh("Concrete Pavement Light", coords_soil, 2030)
        applyMaterial("Concrete Pavement Light", 0.487, 0.487, 0.487)
        moveToCollection("Soil")
        cleanUp()

    if 2031 in coords_soil_array[:,2]:
        # Concrete Pavement Light
        createSoilMesh("Concrete Pavement Light", coords_soil, 2031)
        applyMaterial("Concrete Pavement Light", 0.487, 0.487, 0.487)
        moveToCollection("Soil")
        cleanUp()

    if 2032 in coords_soil_array[:,2]:
        # Concrete Pavement Dark
        createSoilMesh("Concrete Pavement Dark", coords_soil, 2032)
        applyMaterial("Concrete Pavement Dark", 0.095, 0.095, 0.095)
        moveToCollection("Soil")
        cleanUp()

    if 2033 in coords_soil_array[:,2]:
        # Concrete Pavement Dark
        createSoilMesh("Concrete Pavement Dark", coords_soil, 2033)
        applyMaterial("Concrete Pavement Dark", 0.095, 0.095, 0.095)
        moveToCollection("Soil")
        cleanUp()

    if 2034 in coords_soil_array[:,2]:
        # Terre battue (Smashed brick)
        createSoilMesh("Terre battue (Smashed brick)", coords_soil, 2034)
        applyMaterial("Terre battue (Smashed brick)", 1.0, 0.216, 0.051)
        moveToCollection("Soil")
        cleanUp()

    if 2035 in coords_soil_array[:,2]:
        # Terre battue (Smashed brick)
        createSoilMesh("Terre battue (Smashed brick)", coords_soil, 2035)
        applyMaterial("Terre battue (Smashed brick)", 1.0, 0.216, 0.051)
        moveToCollection("Soil")
        cleanUp()

    if 2036 in coords_soil_array[:,2]:
        # Asphalt road with red coating
        createSoilMesh("Asphalt road with red coating", coords_soil, 2036)
        applyMaterial("Asphalt road with red coating", 1.0, 0.216, 0.051)
        moveToCollection("Soil")
        cleanUp()

    if 2037 in coords_soil_array[:,2]:
        # Asphalt road with red coating
        createSoilMesh("Asphalt road with red coating", coords_soil, 2037)
        applyMaterial("Asphalt road with red coating", 1.0, 0.052, 0.047)
        moveToCollection("Soil")
        cleanUp()

        # Basalt Brick Road
    if 2038 in coords_soil_array[:,2]:
        createSoilMesh("Basalt Brick Road", coords_soil, 2038)
        applyMaterial("Basalt Brick Road", 0.077, 0.080, 0.045)
        moveToCollection("Soil")
        cleanUp()

    if 2039 in coords_soil_array[:,2]:
        # Basalt Brick Road
        createSoilMesh("Basalt Brick Road", coords_soil, 2039)
        applyMaterial("Basalt Brick Road", 0.077, 0.080, 0.045)
        moveToCollection("Soil")
        cleanUp()

    if 2040 in coords_soil_array[:,2]:
        # Wood Planks
        createSoilMesh("Wood Planks", coords_soil, 2040)
        applyMaterial("Wood Planks", 0.235, 0.112, 0.054)
        moveToCollection("Soil")
        cleanUp()

    if 2041 in coords_soil_array[:,2]:
        # Wood Planks
        createSoilMesh("Wood Planks", coords_soil, 2041)
        applyMaterial("Wood Planks", 0.235, 0.112, 0.054)
        moveToCollection("Soil")
        cleanUp()

    # Create "Undefined Soil" if soil id does not exist
    for i in range(2042, int(np.amax(soilprofiletype)+1)):
        if i in coords_soil_array[:,2]:
            # Undefined Soil
            createSoilMesh("Undefined Soil", coords_soil, i)
            applyMaterial("Undefined Soil", 1, 1, 1)
            moveToCollection("Soil")
            cleanUp()


# ------------------------------------------------------------------------
#    Air Temperature
# ------------------------------------------------------------------------

def getAirTemperature(height, sim_time):
    """Creates a list of coordinates for air temperature and calls mesh funcions"""
    
    f = netCDF4.Dataset(selected_file)
    
    # Import temperature as masked array (to avoid -999 as missing values)
    temp = f.variables["T"]
    time = np.array(f.variables["Time"])

    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")
   
    # Round numbers
    time = np.around(time, 2)

    # Simulation min and max temperature
    temp_sim_min = np.nanmin(temp)
    temp_sim_max = np.nanmax(temp)

    # Convert masked array to numpy array
    temp = np.array(temp)


    # Create list of coordinates for air temperature
    coords_temp = []
    for y in range(0,len(loc_y)):
        for x in range(0,len(loc_x)):
            coords_temp.append((loc_x[x], loc_y[y], loc_z[height], float(temp[sim_time,height,y,x]), size_x[x], size_y[y], size_z[height],
                                round(1 + (float(temp[sim_time,height,y,x])-temp_sim_min) * (20-(1)) / (temp_sim_max-temp_sim_min),0)))
                                # Normalize and round temperature values to get numbers between 1 and 20
                                # These numbers are used to create 20 different color values

    # Create new collection
    collection = bpy.data.collections.new("Temperature, height: " + str(height) + ", time: " + str(sim_time))
    bpy.context.scene.collection.children.link(collection)

    # Convert list to numpy array
    coords_temp_array = np.array(coords_temp)
    

    # Get air temperature mesh
    if 1 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 1", coords_temp, 1)
        applyMaterial("temperatureValue1", 0, 0, 1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 2 in coords_temp_array[:,7]:        
        createAirTempMesh("Temperature Value 2", coords_temp, 2)
        applyMaterial("temperatureValue2", 0, 0.1, 1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 3 in coords_temp_array[:,7]:        
        createAirTempMesh("Temperature Value 3", coords_temp, 3)
        applyMaterial("temperatureValue3", 0, 0.25, 1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()        
            
    if 4 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 4", coords_temp, 4)
        applyMaterial("temperatureValue4", 0, 0.5, 1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 5 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 5", coords_temp, 5)
        applyMaterial("temperatureValue5", 0, 1, 1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 6 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 6", coords_temp, 6)
        applyMaterial("temperatureValue6", 0, 1, 0.5)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 7 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 7", coords_temp, 7)
        applyMaterial("temperatureValue7", 0, 1, 0.25)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 8 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 8", coords_temp, 8)
        applyMaterial("temperatureValue8", 0, 1, 0.1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 9 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 9", coords_temp, 9)
        applyMaterial("temperatureValue9", 0, 1, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 10 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 10", coords_temp, 10)
        applyMaterial("temperatureValue10", 0.1, 1, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 11 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 11", coords_temp, 11)
        applyMaterial("temperatureValue11", 0.25, 1, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 12 in coords_temp_array[:,7]:        
        createAirTempMesh("Temperature Value 12", coords_temp, 12)
        applyMaterial("temperatureValue12", 0.5, 1, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 13 in coords_temp_array[:,7]:        
        createAirTempMesh("Temperature Value 13", coords_temp, 13)
        applyMaterial("temperatureValue13", 1, 1, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()        
            
    if 14 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 14", coords_temp, 14)
        applyMaterial("temperatureValue14", 1, 0.5, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()

    if 15 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 15", coords_temp, 15)
        applyMaterial("temperatureValue15", 1, 0.25, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 16 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 16", coords_temp, 16)
        applyMaterial("temperatureValue16", 1, 0.1, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 17 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 17", coords_temp, 17)
        applyMaterial("temperatureValue17", 1, 0, 0)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 18 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 18", coords_temp, 18)
        applyMaterial("temperatureValue18", 1, 0, 0.1)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 19 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 19", coords_temp, 19)
        applyMaterial("temperatureValue19", 1, 0, 0.25)
        moveAirTempToCollection(sim_time, height)
        cleanUp()
            
    if 20 in coords_temp_array[:,7]:
        createAirTempMesh("Temperature Value 20", coords_temp, 20)
        applyMaterial("temperatureValue20", 1, 0, 0.5)
        moveAirTempToCollection(sim_time, height)
        cleanUp()


# ------------------------------------------------------------------------
#    TAirBiomet
# ------------------------------------------------------------------------

def getTAirBiomet(sim_time):
    """Creates a list of coordinates for TAirBiomet and calls mesh functions"""
  
    f = netCDF4.Dataset(selected_file)

    time = np.array(f.variables["Time"])
    z_node = np.array(f.variables["ZNodeBiomet"])
    t_air_biomet = np.array(f.variables["TAirBiomet"])

    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")

    # Round values
    time = np.around(time, 2)

    # List of heights
    global added_height
    added_height = [0, size_z[0]]
    for i in range(1,len(size_z)):
        h = size_z[i] + added_height[-1]
        added_height.append(h)

    # Simulation min and max TAirBiomet
    temp_sim_min = np.nanmin(t_air_biomet)
    temp_sim_max = np.nanmax(t_air_biomet)


    # Create list of coordinates for TAirBiomet
    coords_tairbiomet = []
    for y in range(0,len(loc_y)):
        for x in range(0,len(loc_x)):
            coords_tairbiomet.append((loc_x[x], loc_y[y], float(t_air_biomet[sim_time,y,x]), size_x[x], size_y[y], int(z_node[0,y,x]),
                                      round(1 + (float(t_air_biomet[sim_time,y,x])-temp_sim_min) * (20-(1)) / (temp_sim_max-temp_sim_min),0)))


    # Create new collection
    collection = bpy.data.collections.new("T Air Biomet, time: " + str(sim_time))
    bpy.context.scene.collection.children.link(collection)

    # Convert list to numpy array
    coords_tairbiomet_array = np.array(coords_tairbiomet)


    # Get TAirBiomet mesh
    if 1 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 1", coords_tairbiomet, 1)
        applyMaterial("tairbiometValue1", 0, 0, 1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 2 in coords_tairbiomet_array[:,6]:        
        createBiometMesh("Temperature Value 2", coords_tairbiomet, 2)
        applyMaterial("tairbiometValue2", 0, 0.1, 1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 3 in coords_tairbiomet_array[:,6]:        
        createBiometMesh("Temperature Value 3", coords_tairbiomet, 3)
        applyMaterial("tairbiometValue3", 0, 0.25, 1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()        
            
    if 4 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 4", coords_tairbiomet, 4)
        applyMaterial("tairbiometValue4", 0, 0.5, 1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 5 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 5", coords_tairbiomet, 5)
        applyMaterial("tairbiometValue5", 0, 1, 1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 6 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 6", coords_tairbiomet, 6)
        applyMaterial("tairbiometValue6", 0, 1, 0.5)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 7 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 7", coords_tairbiomet, 7)
        applyMaterial("tairbiometValue7", 0, 1, 0.25)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 8 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 8", coords_tairbiomet, 8)
        applyMaterial("tairbiometValue8", 0, 1, 0.1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 9 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 9", coords_tairbiomet, 9)
        applyMaterial("tairbiometValue9", 0, 1, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 10 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 10", coords_tairbiomet, 10)
        applyMaterial("tairbiometValue10", 0.1, 1, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 11 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 11", coords_tairbiomet, 11)
        applyMaterial("tairbiometValue11", 0.25, 1, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 12 in coords_tairbiomet_array[:,6]:        
        createBiometMesh("Temperature Value 12", coords_tairbiomet, 12)
        applyMaterial("tairbiometValue12", 0.5, 1, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 13 in coords_tairbiomet_array[:,6]:        
        createBiometMesh("Temperature Value 13", coords_tairbiomet, 13)
        applyMaterial("tairbiometValue13", 1, 1, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()        
            
    if 14 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 14", coords_tairbiomet, 14)
        applyMaterial("tairbiometValue14", 1, 0.5, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 15 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 15", coords_tairbiomet, 15)
        applyMaterial("tairbiometValue15", 1, 0.25, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 16 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 16", coords_tairbiomet, 16)
        applyMaterial("tairbiometValue16", 1, 0.1, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 17 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 17", coords_tairbiomet, 17)
        applyMaterial("tairbiometValue17", 1, 0, 0)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 18 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 18", coords_tairbiomet, 18)
        applyMaterial("tairbiometValue18", 1, 0, 0.1)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 19 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 19", coords_tairbiomet, 19)
        applyMaterial("tairbiometValue19", 1, 0, 0.25)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 20 in coords_tairbiomet_array[:,6]:
        createBiometMesh("Temperature Value 20", coords_tairbiomet, 20)
        applyMaterial("tairbiometValue20", 1, 0, 0.5)
        moveToCollection("T Air Biomet, time: " + str(sim_time))
        cleanUp()


# ------------------------------------------------------------------------
#    QAirBiomet
# ------------------------------------------------------------------------

def getQAirBiomet(sim_time):
    """Creates a list of coordinates for QAirBiomet and calls mesh functions"""
    
    f = netCDF4.Dataset(selected_file)
    
    time = np.array(f.variables["Time"])
    z_node = np.array(f.variables["ZNodeBiomet"])
    q_air_biomet = np.array(f.variables["QAirBiomet"])

    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")

    # Round values
    time = np.around(time, 2)

    # List of added heights
    global added_height
    added_height = [0, size_z[0]]
    for i in range(1,len(size_z)):
        h = size_z[i] + added_height[-1]
        added_height.append(h)

    # Simulation min and max QAirBiomet
    hum_sim_min = np.nanmin(q_air_biomet)
    hum_sim_max = np.nanmax(q_air_biomet)


    # Create list of coordinates for QAirBiomet
    coords_qairbiomet = []
    for y in range(0,len(loc_y)):
        for x in range(0,len(loc_x)):
            coords_qairbiomet.append((loc_x[x], loc_y[y], float(q_air_biomet[sim_time,y,x]), size_x[x], size_y[y], int(z_node[0,y,x]),
                                      round(1 + (float(q_air_biomet[sim_time,y,x])-hum_sim_min) * (20-(1)) / (hum_sim_max-hum_sim_min),0)))


    # Create new collection
    collection = bpy.data.collections.new("Q Air Biomet, time: " + str(sim_time))
    bpy.context.scene.collection.children.link(collection)

    # Convert list to numpy array
    coords_qairbiomet_array = np.array(coords_qairbiomet)


    if 1 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 1", coords_qairbiomet, 1)
        applyMaterial("qairbiometValue1", 0, 0, 1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 2 in coords_qairbiomet_array[:,6]:        
        createBiometMesh("Humidity Value 2", coords_qairbiomet, 2)
        applyMaterial("qairbiometValue2", 0, 0.1, 1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 3 in coords_qairbiomet_array[:,6]:        
        createBiometMesh("Humidity Value 3", coords_qairbiomet, 3)
        applyMaterial("qairbiometValue3", 0, 0.25, 1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()        
            
    if 4 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 4", coords_qairbiomet, 4)
        applyMaterial("qairbiometValue4", 0, 0.5, 1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 5 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 5", coords_qairbiomet, 5)
        applyMaterial("qairbiometValue5", 0, 1, 1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 6 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 6", coords_qairbiomet, 6)
        applyMaterial("qairbiometValue6", 0, 1, 0.5)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 7 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 7", coords_qairbiomet, 7)
        applyMaterial("qairbiometValue7", 0, 1, 0.25)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 8 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 8", coords_qairbiomet, 8)
        applyMaterial("qairbiometValue8", 0, 1, 0.1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 9 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 9", coords_qairbiomet, 9)
        applyMaterial("qairbiometValue9", 0, 1, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 10 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 10", coords_qairbiomet, 10)
        applyMaterial("qairbiometValue10", 0.1, 1, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 11 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 11", coords_qairbiomet, 11)
        applyMaterial("qairbiometValue11", 0.25, 1, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 12 in coords_qairbiomet_array[:,6]:        
        createBiometMesh("Humidity Value 12", coords_qairbiomet, 12)
        applyMaterial("qairbiometValue12", 0.5, 1, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 13 in coords_qairbiomet_array[:,6]:        
        createBiometMesh("Humidity Value 13", coords_qairbiomet, 13)
        applyMaterial("qairbiometValue13", 1, 1, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()        
            
    if 14 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 14", coords_qairbiomet, 14)
        applyMaterial("qairbiometValue14", 1, 0.5, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()

    if 15 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 15", coords_qairbiomet, 15)
        applyMaterial("qairbiometValue15", 1, 0.25, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 16 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 16", coords_qairbiomet, 16)
        applyMaterial("qairbiometValue16", 1, 0.1, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 17 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 17", coords_qairbiomet, 17)
        applyMaterial("qairbiometValue17", 1, 0, 0)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 18 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 18", coords_qairbiomet, 18)
        applyMaterial("qairbiometValue18", 1, 0, 0.1)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 19 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 19", coords_qairbiomet, 19)
        applyMaterial("qairbiometValue19", 1, 0, 0.25)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
            
    if 20 in coords_qairbiomet_array[:,6]:
        createBiometMesh("Humidity Value 20", coords_qairbiomet, 20)
        applyMaterial("qairbiometValue20", 1, 0, 0.5)
        moveToCollection("Q Air Biomet, time: " + str(sim_time))
        cleanUp()
        

# ------------------------------------------------------------------------
#    Single Walls
# ------------------------------------------------------------------------
def getSingleWalls():
    """Creates a list of coordinates for every wall axis and calls mesh functions"""
        
    f = netCDF4.Dataset(selected_file)
    
    wall_x = np.array(f.variables["XFac_WallDBIndex"])
    wall_y = np.array(f.variables["YFac_WallDBIndex"])
    wall_z = np.array(f.variables["ZFac_WallDBIndex"])

    # Use leaf temperature to define if a wall has greening
    try:
        # If greening variables exist
        x_greening = np.array(f.variables["XFac_GreeningTLeaves"])
        y_greening = np.array(f.variables["YFac_GreeningTLeaves"])
        z_greening = np.array(f.variables["ZFac_GreeningTLeaves"])
    
    except KeyError:
        # Else create a new array with -999 values
        x_greening = np.where(wall_x > 0, -999, wall_x)
        y_greening = np.where(wall_y > 0, -999, wall_y)
        z_greening = np.where(wall_z > 0, -999, wall_z)


    loc_x = np.array(f.variables["GridsI"])
    loc_y = np.array(f.variables["GridsJ"])
    loc_z = np.array(f.variables["GridsK"])

    size_x = f.getncattr("SizeDX")
    size_y = f.getncattr("SizeDY")
    size_z = f.getncattr("SizeDZ")


    # Create list of coordinates for x-walls and x-greening
    coords_walls_x = []
    for z in range(0,len(loc_z)):
        for y in range(0,len(loc_y)):
            for x in range(0,len(loc_x)):
                coords_walls_x.append((loc_x[x], loc_y[y], loc_z[z], int(wall_x[0,z,y,x]), size_x[x], size_y[y], size_z[z], int(x_greening[0,z,y,x])))


    # Create list of coordinates for y-walls and y-greening
    coords_walls_y = []
    for z in range(0,len(loc_z)):
        for y in range(0,len(loc_y)):
            for x in range(0,len(loc_x)):
                coords_walls_y.append((loc_x[x], loc_y[y], loc_z[z], int(wall_y[0,z,y,x]), size_x[x], size_y[y], size_z[z], int(y_greening[0,z,y,x])))


    # Create list of coordinates for z-walls and z-greening
    coords_walls_z = []
    for z in range(0,len(loc_z)):
        for y in range(0,len(loc_y)):
            for x in range(0,len(loc_x)):
                coords_walls_z.append((loc_x[x], loc_y[y], loc_z[z], int(wall_z[0,z,y,x]), size_x[x], size_y[y], size_z[z], int(z_greening[0,z,y,x])))


    # Create a new collection for walls
    collection = bpy.data.collections.new("Walls")
    bpy.context.scene.collection.children.link(collection)

    # Convert lists to numpy arrays
    coords_walls_x_array = np.array(coords_walls_x)
    coords_walls_y_array = np.array(coords_walls_y)
    coords_walls_z_array = np.array(coords_walls_z)


    # Get walls mesh
    getSingleWallsCall(coords_walls_x_array, createSingleWallX)
    getSingleWallsCall(coords_walls_y_array, createSingleWallY)
    getSingleWallsCall(coords_walls_z_array, createSingleWallZ)

    # Get undefined walls mesh
    getUndefinedWallsCall(wall_x, coords_walls_x_array, createSingleWallX)
    getUndefinedWallsCall(wall_y, coords_walls_y_array, createSingleWallY) 
    getUndefinedWallsCall(wall_z, coords_walls_z_array, createSingleWallZ) 

    # Get greening mesh
    getGreeningCall(x_greening, coords_walls_x_array, createGreeningX)
    getGreeningCall(y_greening, coords_walls_y_array, createGreeningY)
    getGreeningCall(z_greening, coords_walls_z_array, createGreeningZ)


def getSingleWallsCall(walls_array, create_wall_function):
    """Calls mesh functions for defined walls"""

    if 0 in walls_array[:,3]:
        # 7000 Passive wall - good insulation
        create_wall_function("Passive wall - good insulation", walls_array, 0)
        applyMaterial("Passive wall - good insulation", 1, 0.7, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 1 in walls_array[:,3]:
        # 7001 Wall - no insulation
        create_wall_function("Wall - no insulation", walls_array, 1)
        applyMaterial("Wall - no insulation", 0.15, 0.03, 0.03)
        moveToCollection("Walls")
        cleanUp()
  
    if 2 in walls_array[:,3]:
        # 7002 Wall - moderate insulation
        create_wall_function("Wall - moderate insulation", walls_array, 2)
        applyMaterial("Wall - moderate insulation", 0.08, 0.06, 0.05)
        moveToCollection("Walls")
        cleanUp()
        
    if 3 in walls_array[:,3]:
        # 7003 Default wall - moderate insulation
        create_wall_function("Default wall - moderate insulation", walls_array, 3)
        applyMaterial("Default wall - moderate insulation", 0.5, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 4 in walls_array[:,3]:
        # 7004 Default wall - moderate insulation
        create_wall_function("Default wall - moderate insulation", walls_array, 4)
        applyMaterial("Default wall - moderate insulation", 0.5, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 5 in walls_array[:,3]:
        # 7005 PVC Sun Sail
        create_wall_function("PVC Sun Sail", walls_array, 5) 
        applyMaterial("PVC Sun Sail", 0.04, 0.2, 0)
        moveToCollection("Walls")
        cleanUp()

    if 6 in walls_array[:,3]:
        # 7006 Concrete Wall, Photoactive
        create_wall_function("Concrete Wall, Photoactive", walls_array, 6)
        applyMaterial("Concrete Wall, Photoactive", 1, 0, 0)
        moveToCollection("Walls")
        cleanUp()

    if 7 in walls_array[:,3]:
        # 7007 Concrete Wall, heavy
        create_wall_function("Concrete Wall, heavy", walls_array, 7)
        applyMaterial("Concrete Wall, heavy", 0.15, 0.12, 0.12)
        moveToCollection("Walls")
        cleanUp()
        
    if 8 in walls_array[:,3]:
        # 7008 Concrete wall (light weight)
        create_wall_function("Concrete wall (light weight)", walls_array, 8)
        applyMaterial("Concrete wall (light weight)", 0.08, 0.08, 0.08)
        moveToCollection("Walls")
        cleanUp()

    if 9 in walls_array[:,3]:
        # 7009 Concrete wall (hollow block)
        create_wall_function("Concrete wall (hollow block)", walls_array, 9) 
        applyMaterial("Concrete wall (hollow block)", 0.3, 0.2, 0.25)
        moveToCollection("Walls")
        cleanUp()

    if 10 in walls_array[:,3]:
        # 7010 Concrete wall (filled block)
        create_wall_function("Concrete wall (filled block)", walls_array, 10) 
        applyMaterial("Concrete wall (filled block)", 0.04, 0.04, 0.04)
        moveToCollection("Walls")
        cleanUp()
    
    if 11 in walls_array[:,3]:
        # 7011 Concrete wall (cast dense)
        create_wall_function("Concrete wall (cast dense)", walls_array, 11) 
        applyMaterial("Concrete wall (cast dense)", 0.05, 0.05, 0.05)
        moveToCollection("Walls")
        cleanUp()

    if 12 in walls_array[:,3]:
        # 7012 Heat Protection Glass (one layered)
        create_wall_function("Heat Protection Glass (one layered)", walls_array, 12)
        applyMaterial("Heat protection Glass (one layered)", 0.5, 1, 0.5, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 13 in walls_array[:,3]:
        # 7013 Plexiglass (one layered)
        create_wall_function("Plexiglass (one layered)", walls_array, 13)
        applyMaterial("Plexiglass (one layered)", 0.5, 0.9, 1, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 14 in walls_array[:,3]:
        # 7014 Foamed Glass (one layered)
        create_wall_function("Foamed Glass (one layered)", walls_array, 14)
        applyMaterial("Foamed Glass (one layered)", 0.06, 0.08, 0.1, 1)
        moveToCollection("Walls")
        cleanUp()

    if 15 in walls_array[:,3]:
        # 7015 Clear float glass (one layered)
        create_wall_function("Clear float glass (one layered)", walls_array, 15)
        applyMaterial("Clear float glass (one layered)", 0.4, 0.9, 1, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 16 in walls_array[:,3]:
        # 7016 Glass Bricks (one layered)
        create_wall_function("Glass Bricks (one layered)", walls_array, 16)
        applyMaterial("Glass Bricks (one layered)", 0.3, 0.4, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 17 in walls_array[:,3]:
        # 7017 Aluminium (single layer)
        create_wall_function("Aluminium (single layer)", walls_array, 17)
        applyMaterial("Aluminium (single layer)", 0.65, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 18 in walls_array[:,3]:
        # 7018 Copper (single layer)
        create_wall_function("Copper (single layer)", walls_array, 18)
        applyMaterial("Copper (single layer)", 0.9, 0.05, 0.01)
        moveToCollection("Walls")
        cleanUp()

    if 19 in walls_array[:,3]:
        # 7019 Iron (single layer)
        create_wall_function("Iron (single layer)", walls_array, 19)
        applyMaterial("Iron (single layer)", 0.35, 0.3, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 20 in walls_array[:,3]:
        # 7020 Steel (one layer)
        create_wall_function("Steel (one layer)", walls_array, 20)
        applyMaterial("Steel (one layer)", 0.2, 0.18, 0.18)
        moveToCollection("Walls")
        cleanUp()

    if 21 in walls_array[:,3]:
        # 7021 Brick wall (aerated)
        create_wall_function("Brick wall (aerated)", walls_array, 21)
        applyMaterial("Brick wall (aerated)", 1, 0.18, 0.03)
        moveToCollection("Walls")
        cleanUp()

    if 22 in walls_array[:,3]:
        # 7022 Brick wall (burned)
        create_wall_function("Brick wall (burned)", walls_array, 22)
        applyMaterial("Brick wall (burned)", 0.35, 0.03, 0.01)
        moveToCollection("Walls")
        cleanUp()

    if 23 in walls_array[:,3]:
        # 7023 Brick wall (reinforced)
        create_wall_function("Brick wall (reinforced)", walls_array, 23)
        applyMaterial("Brick wall (reinforced)", 0.3, 0, 0)
        moveToCollection("Walls")
        cleanUp()

    if 24 in walls_array[:,3]:
        # 7024 Roofing: Tile
        create_wall_function("Roofing: Tile", walls_array, 24)
        applyMaterial("Roofing: Tile", 0.5, 0.25, 0.015)
        moveToCollection("Walls")
        cleanUp()

    if 25 in walls_array[:,3]:
        # 7025 Roofing: Terracotta
        create_wall_function("Roofing: Terracotta", walls_array, 25)
        applyMaterial("Roofing: Terracotta", 0.5, 0.12, 0.012)
        moveToCollection("Walls")
        cleanUp()

    if 26 in walls_array[:,3]:
        # 7026 Heat protection glass (one air layer)
        create_wall_function("Heat protection glass (one air layer)", walls_array, 26)
        applyMaterial("Heat protection glass (one air layer)", 0.5, 1, 0.5, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 27 in walls_array[:,3]:
        # 7027 WetRoof
        create_wall_function("WetRoof", walls_array, 27)
        applyMaterial("WetRoof", 0.06, 0.12, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 28 in walls_array[:,3]:
        # 7028 Shading Plexiglass
        create_wall_function("Shading Plexiglass", walls_array, 28)
        applyMaterial("Shading Plexiglass", 0.15, 0.15, 0.15, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 29 in walls_array[:,3]:
        # 7029 Concrete slab (hollow block, default)
        create_wall_function(" Concrete slab (hollow block, default)", walls_array, 29)
        applyMaterial("Concrete slab (hollow block, default)", 0.5, 0.22, 0.15)
        moveToCollection("Walls")
        cleanUp()
        
    if 30 in walls_array[:,3]:
        # 7030 Passive wall - good insulation
        create_wall_function("Passive wall - good insulation", walls_array, 30)
        applyMaterial("Passive wall - good insulation", 1, 0.7, 0.3)
        moveToCollection("Walls")
        cleanUp()
        
    if 31 in walls_array[:,3]:
        # 7031 Wall - no insulation
        create_wall_function("Wall - no insulation", walls_array, 31)
        applyMaterial("Wall - no insulation", 0.15, 0.03, 0.03)
        moveToCollection("Walls")
        cleanUp()

    if 32 in walls_array[:,3]:
        # 7032 Wall - moderate insulation
        create_wall_function("Wall - moderate insulation", walls_array, 32)
        applyMaterial("Wall - moderate insulation", 0.08, 0.06, 0.05)
        moveToCollection("Walls")
        cleanUp()
        
    if 33 in walls_array[:,3]:
        # 7033 Default wall - moderate insulation
        create_wall_function("Default wall - moderate insulation", walls_array, 33)
        applyMaterial("Default wall - moderate insulation", 0.5, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 34 in walls_array[:,3]:
        # 7034 Default wall - moderate insulation
        create_wall_function("Default wall - moderate insulation", walls_array, 34)
        applyMaterial("Default wall - moderate insulation", 0.5, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 35 in walls_array[:,3]:
        # 7035 PVC Sun Sail
        create_wall_function("PVC Sun Sail", walls_array, 35) 
        applyMaterial("PVC Sun Sail", 0.04, 0.2, 0)
        moveToCollection("Walls")
        cleanUp()

    if 36 in walls_array[:,3]:
        # 7036 Concrete Wall, Photoactive
        create_wall_function("Concrete Wall, Photoactive", walls_array, 36)
        applyMaterial("Concrete Wall, Photoactive", 1, 0, 0)
        moveToCollection("Walls")
        cleanUp()

    if 37 in walls_array[:,3]:
        # 7037 Concrete Wall, heavy
        create_wall_function("Concrete Wall, heavy", walls_array, 37)
        applyMaterial("Concrete Wall, heavy", 0.15, 0.12, 0.12)
        moveToCollection("Walls")
        cleanUp()
        
    if 38 in walls_array[:,3]:
        # 7038 Concrete wall (light weight)
        create_wall_function("Concrete wall (light weight)", walls_array, 38)
        applyMaterial("Concrete wall (light weight)", 0.08, 0.08, 0.08)
        moveToCollection("Walls")
        cleanUp()

    if 39 in walls_array[:,3]:
        # 7039 Concrete wall (hollow block)
        create_wall_function("Concrete wall (hollow block)", walls_array, 39) 
        applyMaterial("Concrete wall (hollow block)", 0.3, 0.2, 0.25)
        moveToCollection("Walls")
        cleanUp()

    if 40 in walls_array[:,3]:
        # 7040 Concrete wall (filled block)
        create_wall_function("Concrete wall (filled block)", walls_array, 40) 
        applyMaterial("Concrete wall (filled block)", 0.04, 0.04, 0.04)
        moveToCollection("Walls")
        cleanUp()
    
    if 41 in walls_array[:,3]:
        # 7041 Concrete wall (cast dense)
        create_wall_function("Concrete wall (cast dense)", walls_array, 41) 
        applyMaterial("Concrete wall (cast dense)", 0.05, 0.05, 0.05)
        moveToCollection("Walls")
        cleanUp()

    if 42 in walls_array[:,3]:
        # 7042 Heat Protection Glass (one layered)
        create_wall_function("Heat Protection Glass (one layered)", walls_array, 42)
        applyMaterial("Heat protection Glass (one layered)", 0.5, 1, 0.5, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 43 in walls_array[:,3]:
        # 7043 Plexiglass (one layered)
        create_wall_function("Plexiglass (one layered)", walls_array, 43)
        applyMaterial("Plexiglass (one layered)", 0.5, 0.9, 1, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 44 in walls_array[:,3]:
        # 7044 Foamed Glass (one layered)
        create_wall_function("Foamed Glass (one layered)", walls_array, 44)
        applyMaterial("Foamed Glass (one layered)", 0.06, 0.08, 0.1, 1)
        moveToCollection("Walls")
        cleanUp()

    if 45 in walls_array[:,3]:
        # 7045 Clear float glass (one layered)
        create_wall_function("Clear float glass (one layered)", walls_array, 45)
        applyMaterial("Clear float glass (one layered)", 0.4, 0.9, 1, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 46 in walls_array[:,3]:
        # 7046 Glass Bricks (one layered)
        create_wall_function("Glass Bricks (one layered)", walls_array, 46)
        applyMaterial("Glass Bricks (one layered)", 0.3, 0.4, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 47 in walls_array[:,3]:
        # 7047 Aluminium (single layer)
        create_wall_function("Aluminium (single layer)", walls_array, 47)
        applyMaterial("Aluminium (single layer)", 0.65, 0.5, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 48 in walls_array[:,3]:
        # 7048 Copper (single layer)
        create_wall_function("Copper (single layer)", walls_array, 48)
        applyMaterial("Copper (single layer)", 0.9, 0.05, 0.01)
        moveToCollection("Walls")
        cleanUp()

    if 49 in walls_array[:,3]:
        # 7049 Iron (single layer)
        create_wall_function("Iron (single layer)", walls_array, 49)
        applyMaterial("Iron (single layer)", 0.35, 0.3, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 50 in walls_array[:,3]:
        # 7050 Steel (one layer)
        create_wall_function("Steel (one layer)", walls_array, 50)
        applyMaterial("Steel (one layer)", 0.2, 0.18, 0.18)
        moveToCollection("Walls")
        cleanUp()

    if 51 in walls_array[:,3]:
        # 7051 Brick wall (aerated)
        create_wall_function("Brick wall (aerated)", walls_array, 51)
        applyMaterial("Brick wall (aerated)", 1, 0.18, 0.03)
        moveToCollection("Walls")
        cleanUp()

    if 52 in walls_array[:,3]:
        # 7052 Brick wall (burned)
        create_wall_function("Brick wall (burned)", walls_array, 52)
        applyMaterial("Brick wall (burned)", 0.35, 0.03, 0.01)
        moveToCollection("Walls")
        cleanUp()

    if 53 in walls_array[:,3]:
        # 7053 Brick wall (reinforced)
        create_wall_function("Brick wall (reinforced)", walls_array, 53)
        applyMaterial("Brick wall (reinforced)", 0.3, 0, 0)
        moveToCollection("Walls")
        cleanUp()

    if 54 in walls_array[:,3]:
        # 7054 Roofing: Tile
        create_wall_function("Roofing: Tile", walls_array, 54)
        applyMaterial("Roofing: Tile", 0.5, 0.25, 0.015)
        moveToCollection("Walls")
        cleanUp()

    if 55 in walls_array[:,3]:
        # 7055 Roofing: Terracotta
        create_wall_function("Roofing: Terracotta", walls_array, 55)
        applyMaterial("Roofing: Terracotta", 0.5, 0.12, 0.012)
        moveToCollection("Walls")
        cleanUp()

    if 56 in walls_array[:,3]:
        # 7056 Heat protection glass (one air layer)
        create_wall_function("Heat protection glass (one air layer)", walls_array, 56)
        applyMaterial("Heat protection glass (one air layer)", 0.5, 1, 0.5, 0.3)
        moveToCollection("Walls")
        cleanUp()

    if 57 in walls_array[:,3]:
        # 7057 WetRoof
        create_wall_function("WetRoof", walls_array, 57)
        applyMaterial("WetRoof", 0.06, 0.12, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 58 in walls_array[:,3]:
        # 7058 Shading Plexiglass
        create_wall_function("Shading Plexiglass", walls_array, 58)
        applyMaterial("Shading Plexiglass", 0.15, 0.15, 0.15, 0.5)
        moveToCollection("Walls")
        cleanUp()

    if 59 in walls_array[:,3]:
        # 7059 Concrete slab (hollow block, default)
        create_wall_function("Concrete slab (hollow block, default)", walls_array, 59)
        applyMaterial("Concrete slab (hollow block, default)", 0.5, 0.22, 0.15)
        moveToCollection("Walls")
        cleanUp()


# Create undefined walls if walls not in database:
def getUndefinedWallsCall(wall, walls_array, create_wall_function) :
    """Calls mesh functions for undefined walls"""
    
    for i in range(60, int(np.amax(wall)+1)):
        if i in walls_array[:,3]:
            # Undefined Wall
            create_wall_function("Undefined Wall", walls_array, i)
            applyMaterial("Undefined Wall", 0.28, 0.28, 0.28)
            moveToCollection("Walls")
            cleanUp()


# Create greening if greening exist:
def getGreeningCall(greening, walls_array, create_greening_function):
    """Calls mesh functions for greening"""
    
    if np.amax(greening) > -999:
        # Greening
        create_greening_function("Greening", walls_array)
        applyMaterial("Greening", 0.2, 0.3, 0)
        moveToCollection("Walls")
        cleanUp()
    

# ------------------------------------------------------------------------
#    Addon:
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#    Properties
# ------------------------------------------------------------------------

class MyProperties(bpy.types.PropertyGroup):


    objects_bool: bpy.props.BoolProperty(
        name= "File contains facades",
        description= "Check this box if your file contains facade info",
        default = False
    )
 
    temp_height_int : bpy.props.IntProperty(
        name = "",
        description = "Height in grids above ground",
        default = 0,
        min = 0,
        max = 50,
    )
        
    temp_time_int : bpy.props.IntProperty(
        name = "",
        description = "Time in hours after simulation start",
        default = 0,
        min = 0,
        max = 48,
    )

    file_display : bpy.props.StringProperty(
        name= "", 
        maxlen= 255, 
        subtype= 'FILE_NAME', 
        default= '', 
        options = {'HIDDEN'},
    )

    tairbiomet_int : bpy.props.IntProperty(
        name = "",
        description = "Time in hours after simulation start",
        default = 0,
        min = 0,
        max = 48,
    )

    qairbiomet_int : bpy.props.IntProperty(
        name = "",
        description = "Time in hours after simulation start",
        default = 0,
        min = 0,
        max = 48,
    )


# ------------------------------------------------------------------------
#    Operators
# ------------------------------------------------------------------------

class Objects_Operator(bpy.types.Operator):
    """Import buildings and vegetation"""
    bl_idname = "objects_operator.1"
    bl_label = "Objects Operator"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        
        if mytool.objects_bool == False:
            try:
                getBuildings()
                getVegetation()
            except OSError:
                self.report({"ERROR"}, "Wrong file format.")
            except NameError:
                self.report({"ERROR"}, "Select a file first.")
                
        if mytool.objects_bool == True:
            try:
                getSingleWalls()
                getVegetation()
            except KeyError:
                self.report({"ERROR"}, "Sorry, your file does not contain any facade info.")
            except OSError:
                self.report({"ERROR"}, "Wrong file format.")
            except NameError:
                self.report({"ERROR"}, "Select a file first.")
        
        return{'FINISHED'}


class Soil_Operator(bpy.types.Operator):
    """Import soil"""
    bl_idname = "soil_operator.1"
    bl_label = "Soil Operator"

    def execute(self, context):
        try:
            getSoil()
        except OSError:
            self.report({"ERROR"}, "Wrong file format.")
        except NameError:
            self.report({"ERROR"}, "Select a file first.")
            
        return{'FINISHED'}


class TAirBiomet_Operator(bpy.types.Operator):
    """Import air temperature at biomet level"""
    bl_idname = "tairbiomet_operator.1"
    bl_label = "Select simulation time to display"

    def invoke(self, context, event):
        wm = context.window_manager

        return wm.invoke_props_dialog(self, width = 180)

    def draw(self,context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
        split = layout.split(factor=0.30)
        split.label(text="time:")
        split.prop(mytool, "tairbiomet_int")

    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool
        
        time = mytool.tairbiomet_int
        
        try:
            getTAirBiomet(time)
        except IndexError:
            self.report({"ERROR"}, "Simulation time out of reach.")
        except OSError:
            self.report({"ERROR"}, "Wrong file format.")
        except NameError:
            self.report({"ERROR"}, "Select a file first.")
        
        return{'FINISHED'}
     


class QAirBiomet_Operator(bpy.types.Operator):
    """Import specific air humidity at biomet level"""
    bl_idname = "qairbiomet_operator.1"
    bl_label = "Select simulation time to display"

    def invoke(self, context, event):
        wm = context.window_manager
        
        return wm.invoke_props_dialog(self, width = 180)

    def draw(self,context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
        split = layout.split(factor=0.30)
        split.label(text="time:")
        split.prop(mytool, "qairbiomet_int")

    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool

        time = mytool.qairbiomet_int
        
        try:
            getQAirBiomet(time)
        except IndexError:
            self.report({"ERROR"}, "Simulation time out of reach.")
        except OSError:
            self.report({"ERROR"}, "Wrong file format.")
        except NameError:
            self.report({"ERROR"}, "Select a file first.")
            
        return{'FINISHED'}
     

class Air_Temperature_Operator(bpy.types.Operator):
    """Import air temperature at custom height and time"""
    bl_idname = "air_temperature_operator.1"
    bl_label = "Select height and time to display"
    
    def invoke(self, context, event):
        wm = context.window_manager
        
        return wm.invoke_props_dialog(self, width = 180)

    def draw(self,context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
        split1 = layout.split(factor=0.30)
        split1.label(text="height:")
        split1.prop(mytool, "temp_height_int")
        split2 = layout.split(factor=0.30)
        split2.label(text="time:")
        split2.prop(mytool, "temp_time_int")

    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool
        
        height = mytool.temp_height_int
        time = mytool.temp_time_int
        
        try:
            getAirTemperature(height,time)
        except IndexError:
            self.report({"ERROR"}, "Simulation height or time out of reach.")
        except OSError:
            self.report({"ERROR"}, "Wrong file format.")
        except NameError:
            self.report({"ERROR"}, "Select a file first.")
            
        return{'FINISHED'}


class File_Import_Operator(Operator, ImportHelper):
    """Only ENVI-met netCDF files are allowed"""
    bl_idname = "file_import_operator.1"
    bl_label = "File path."

    filename_ext = ".nc"

    filter_glob: StringProperty(
        default="*.nc",
        options={'HIDDEN'},
        maxlen=255
    )

    def execute(self, context):
        global selected_file
        selected_file = self.properties.filepath
        
        scene = context.scene
        mytool = scene.my_tool
        mytool.file_display = self.properties.filepath
        
        return {'FINISHED'}


# ------------------------------------------------------------------------
#    Panel
# ------------------------------------------------------------------------

class MyCustomPanel(bpy.types.Panel):
    bl_label = "NetCDF Importer"
    bl_idname = "N_PT_ID"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NetCDF Importer"

    def draw(self, context):
        
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
        # Panel label:
        layout.label(text="Load in *.nc files", icon="INFO")

        # First box:
        box1 = layout.box()
        box1.label(text="File path", icon="OUTLINER_OB_GROUP_INSTANCE")
        split1 = box1.split(factor=0.85, align=True)
        split1.prop(mytool, "file_display")
        split1.operator("file_import_operator.1", text="", icon="FILEBROWSER")

        # Second box:
        box2 = layout.box()        
        box2.label(text="Import Area", icon="WORLD")
        box2.prop(mytool, "objects_bool")
        split2 = box2.split(factor=0.50, align=False)
        split2.operator("objects_operator.1", text="Objects", icon="IMPORT")
        split2.operator("soil_operator.1", text="Soil", icon="IMPORT")

        # Third box:        
        box3 = layout.box()
        box3.label(text="Simulation Data", icon="MOD_DATA_TRANSFER")
        split3 = box3.split(factor=0.75, align=True)
        split3.label(text="T Air Biomet", icon="KEYTYPE_JITTER_VEC" )
        split3.operator("tairbiomet_operator.1", text="", icon="IMPORT")
        
        split4 = box3.split(factor=0.75, align=True)
        split4.label(text="Q Air Biomet", icon="KEYTYPE_BREAKDOWN_VEC")
        split4.operator("qairbiomet_operator.1", text="", icon="IMPORT")
        
        split5 = box3.split(factor=0.75, align=True)
        split5.label(text="T Air Custom", icon="KEYTYPE_MOVING_HOLD_VEC")
        split5.operator("air_temperature_operator.1",text="", icon="IMPORT")    


# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyProperties,
    Objects_Operator,
    Soil_Operator,
    TAirBiomet_Operator,
    QAirBiomet_Operator,
    Air_Temperature_Operator,
    File_Import_Operator,
    MyCustomPanel,
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type=MyProperties)


def unregister():
    from bpy.utils import unregister_class
    for cls in classes:
        unregister_class(cls)


if __name__ == "__main__":
    register()
